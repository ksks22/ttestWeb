# app.py
from flask import Flask, render_template, request, redirect, url_for, flash
import os
from werkzeug.utils import secure_filename
from math import ceil

app = Flask(__name__, template_folder='D:/my_flask_app/templates', static_folder='D:/my_flask_app/static')
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.expanduser('~'), 'flask_uploads')  # 更改路径为用户目录下的 flask_uploads 文件夹
app.config['ALLOWED_EXTENSIONS'] = {'txt', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
                                    'jpg', 'jpeg', 'png', 'gif', 'bmp', 'mp3', 'wav', 'flac', 'aac',
                                    'mp4', 'avi', 'mkv', 'wmv', 'zip', 'rar', '7z', 'exe', 'dll', 'py', 'java',
                                    'dmg', 'iso', 'psd', 'indd', 'raw', 'wma', 'mid', 'midi', 'torrent', 'accdb', 'odt',
                                    'pst', 'tmp', 'cfg', 'log'}
app.secret_key = 'supersecretkey'

# 确保 uploads 目录及其子目录存在
required_dirs = ['images', 'videos', 'documents', 'audios', 'programs', 'compressed', 'others']
for dir_name in required_dirs:
    os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], dir_name), exist_ok=True)

def allowed_file(filename):
    return '.' in filename and \
        filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/', methods=['GET'])
def index():
    search_query = request.args.get('search', '')
    page = int(request.args.get('page', 1))
    per_page = 5

    # 获取所有文件并过滤
    all_files = []
    image_files = [f for f in os.listdir(os.path.join(app.config['UPLOAD_FOLDER'], 'images')) if
                   f.endswith(tuple(['.png', '.jpg', '.jpeg', '.gif', '.bmp']))]
    video_files = [f for f in os.listdir(os.path.join(app.config['UPLOAD_FOLDER'], 'videos')) if
                   f.endswith(tuple(['.mp4', '.avi', '.mkv', '.wmv']))]
    document_files = [f for f in os.listdir(os.path.join(app.config['UPLOAD_FOLDER'], 'documents')) if
                      f.endswith(tuple(['.txt', '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx']))]
    audio_files = [f for f in os.listdir(os.path.join(app.config['UPLOAD_FOLDER'], 'audios')) if
                   f.endswith(tuple(['.mp3', '.wav', '.flac', '.aac', '.wma']))]
    program_files = [f for f in os.listdir(os.path.join(app.config['UPLOAD_FOLDER'], 'programs')) if
                     f.endswith(tuple(['.exe', '.dll', '.py', '.java']))]
    compressed_files = [f for f in os.listdir(os.path.join(app.config['UPLOAD_FOLDER'], 'compressed')) if
                        f.endswith(tuple(['.zip', '.rar', '.7z']))]
    other_files = [f for f in os.listdir(os.path.join(app.config['UPLOAD_FOLDER'], 'others')) if f.endswith(tuple(
        ['.dmg', '.iso', '.psd', '.indd', '.raw', '.mid', '.midi', '.torrent', '.accdb', '.odt', '.pst', '.tmp', '.cfg',
         '.log']))]

    all_files.extend([('image', f) for f in image_files])
    all_files.extend([('video', f) for f in video_files])
    all_files.extend([('document', f) for f in document_files])
    all_files.extend([('audio', f) for f in audio_files])
    all_files.extend([('program', f) for f in program_files])
    all_files.extend([('compressed', f) for f in compressed_files])
    all_files.extend([('other', f) for f in other_files])

    if search_query:
        all_files = [file for file in all_files if search_query.lower() in file[1].lower()]

    total_pages = ceil(len(all_files) / per_page)
    start_index = (page - 1) * per_page
    end_index = start_index + per_page
    files_to_display = all_files[start_index:end_index]

    return render_template('index.html', files=files_to_display, total_pages=total_pages, current_page=page,
                           search_query=search_query)

@app.route('/upload', methods=['POST'])
def upload_file():
    try:
        if 'file' not in request.files:
            flash('没有文件部分')
            return redirect(request.url)
        file = request.files['file']
        # 如果用户没有选择文件，浏览器也会提交一个空的part-without-filename
        if file.filename == '':
            flash('没有选择文件')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)

            # 根据文件类型将其保存到相应的目录
            save_path = None
            if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
                save_path = os.path.join(app.config['UPLOAD_FOLDER'], 'images', filename)
            elif filename.lower().endswith(('.mp4', '.avi', '.mkv', '.wmv')):
                save_path = os.path.join(app.config['UPLOAD_FOLDER'], 'videos', filename)
            elif filename.lower().endswith(('.txt', '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx')):
                save_path = os.path.join(app.config['UPLOAD_FOLDER'], 'documents', filename)
            elif filename.lower().endswith(('.mp3', '.wav', '.flac', '.aac', '.wma')):
                save_path = os.path.join(app.config['UPLOAD_FOLDER'], 'audios', filename)
            elif filename.lower().endswith(('.exe', '.dll', '.py', '.java')):
                save_path = os.path.join(app.config['UPLOAD_FOLDER'], 'programs', filename)
            elif filename.lower().endswith(('.zip', '.rar', '.7z')):
                save_path = os.path.join(app.config['UPLOAD_FOLDER'], 'compressed', filename)
            else:
                save_path = os.path.join(app.config['UPLOAD_FOLDER'], 'others', filename)

            print(f"Save path: {save_path}")  # 调试信息
            if save_path:
                file.save(save_path)
                print(f"File saved to {save_path}")  # 调试信息
                flash(f'文件 {filename} 上传成功！')
            else:
                flash('无法确定文件类型或保存路径。')
        else:
            flash(
                '允许的文件类型包括：txt, pdf, doc, docx, xls, xlsx, ppt, pptx, jpg, jpeg, png, gif, bmp, mp3, wav, flac, aac, wma, mp4, avi, mkv, wmv, zip, rar, 7z, exe, dll, py, java, dmg, iso, psd, indd, raw, mid, midi, torrent, accdb, odt, pst, tmp, cfg, log')
        return redirect(url_for('index'))
    except PermissionError as e:
        flash(f'权限错误: {str(e)}')
        print(f"Permission error: {str(e)}")  # 调试信息
    except Exception as e:
        flash(f'发生错误: {str(e)}')
        print(f"Exception: {str(e)}")  # 调试信息
    return redirect(url_for('index'))

@app.route('/delete/<path:filename>', methods=['POST'])
def delete_file(filename):
    # 确定文件路径
    file_path = None
    if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'images', filename)
    elif filename.lower().endswith(('.mp4', '.avi', '.mkv', '.wmv')):
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'videos', filename)
    elif filename.lower().endswith(('.txt', '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx')):
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'documents', filename)
    elif filename.lower().endswith(('.mp3', '.wav', '.flac', '.aac', '.wma')):
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'audios', filename)
    elif filename.lower().endswith(('.exe', '.dll', '.py', '.java')):
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'programs', filename)
    elif filename.lower().endswith(('.zip', '.rar', '.7z')):
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'compressed', filename)
    else:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'others', filename)

    if file_path and os.path.exists(file_path):
        os.remove(file_path)
        flash(f'文件 {filename} 已删除。')
    else:
        flash(f'文件 {filename} 不存在。')

    return redirect(url_for('index'))

@app.route('/detail/<path:filename>', methods=['GET'])
def detail(filename):
    # 确定文件路径
    file_type = None
    if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
        file_type = 'image'
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'images', filename)
    elif filename.lower().endswith(('.mp4', '.avi', '.mkv', '.wmv')):
        file_type = 'video'
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'videos', filename)
    elif filename.lower().endswith(('.txt', '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx')):
        file_type = 'document'
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'documents', filename)
    elif filename.lower().endswith(('.mp3', '.wav', '.flac', '.aac', '.wma')):
        file_type = 'audio'
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'audios', filename)
    elif filename.lower().endswith(('.exe', '.dll', '.py', '.java')):
        file_type = 'program'
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'programs', filename)
    elif filename.lower().endswith(('.zip', '.rar', '.7z')):
        file_type = 'compressed'
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'compressed', filename)
    else:
        file_type = 'other'
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'others', filename)

    if file_path and os.path.exists(file_path):
        relative_path = file_path.replace(os.path.expanduser('~') + '\\flask_uploads\\', '')
        return render_template('detail.html', filename=filename, file_path=relative_path, file_type=file_type)
    else:
        flash(f'文件 {filename} 不存在。')
        return redirect(url_for('index'))

if __name__ == '__main__':
    print("UPLOAD_FOLDER:", app.config['UPLOAD_FOLDER'])  # 打印上传文件夹路径
    app.run(debug=True)



